rm -rf /tmp/ray

python /home/zzy/catkin_ws/src/gym/gym/envs/robotics/algos/sia_arm/rllib_train_sia123.py --run PPO
